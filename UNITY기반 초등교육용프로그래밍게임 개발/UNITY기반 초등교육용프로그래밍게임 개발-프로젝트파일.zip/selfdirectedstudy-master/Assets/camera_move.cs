﻿using UnityEngine;
using System.Collections;

public class camera_move : MonoBehaviour {
    public Vector3 ResetCamera;
    private Vector3 Origin;
    private Vector3 Difference;
    private bool Drag = false;
	private float zoomSize = 5;
    void Start()
    {
        ResetCamera = Camera.main.transform.position;
    }
    void LateUpdate()
    {
        if (Input.GetMouseButton(0) && Input.GetKey(KeyCode.A))
        {
            Difference = (Camera.main.ScreenToWorldPoint(Input.mousePosition)) - Camera.main.transform.position;
            if (Drag == false)
            {
                Drag = true;
                Origin = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            }
        }
        else {
            Drag = false;
        }
        if (Drag == true)
        {
            Camera.main.transform.position = Origin - Difference;
        }
        //RESET CAMERA TO STARTING POSITION WITH RIGHT CLICK
		if (Input.GetMouseButton(1))
		{
			Camera.main.transform.position = ResetCamera;
			zoomSize = 5;
		}

		if (Input.GetAxis("Mouse ScrollWheel")>0)
        {
			if (zoomSize > 5)
				zoomSize -= 1;
			//GetComponent<Transform> ().position = new Vector3 (transform.position.x, transform.position.y - .3f, transform.position.z);
			//transform.Rotate (0, -2, 0);

        }


		if (Input.GetAxis("Mouse ScrollWheel")<0)
		{ 
			if (zoomSize < 25) {
				zoomSize += 1;
			}
			//GetComponent<Transform> ().position = new Vector3 (transform.position.x, transform.position.y + .3f, transform.position.z);
			//transform.Rotate (0, 2, 0);

		}  
		GetComponent<Camera>().orthographicSize = zoomSize;
    }


}
