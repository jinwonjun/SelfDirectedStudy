﻿using UnityEngine;
using System.Collections;

public class camera : MonoBehaviour {

	public GameObject player;
	//public float offsetX = 0f;
	//public float offsetY = 25f;
	//public float offsetZ = -35f;

	Vector3 cameraPosition;
	// Use this for initialization

	// Update is called once per frame
	void LateUpdate () {
	
		GameObject player = transform.FindChild("player").gameObject;
		transform.position = new Vector3 (player.transform.position.x, player.transform.position.y);

		//cameraPosition.x = player.transform.position.x;
		//cameraPosition.y = player.transform.position.y;
		//cameraPosition.z = player.transform.position.z + offsetZ;

		//transform.position = cameraPosition;

		Debug.Log ("CAMERA position X:" + transform.position.x + "  Y:" + transform.position.y);
	}
}
