﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;

public class Input_Step : MonoBehaviour {

    public int step;
    public GameObject Input;

    void Start()
    {
        
        var input = gameObject.GetComponent<InputField>();
        var se = new InputField.SubmitEvent();
        se.AddListener(SubmitName);
        input.onEndEdit = se;
        
        
        //or simply use the line below, 
        //input.onEndEdit.AddListener(SubmitName);  // This also works
    }

    void SubmitName(string arg0)
    {
        Debug.Log(arg0);
        this.step = System.Convert.ToInt32(arg0);
        
    }
}
