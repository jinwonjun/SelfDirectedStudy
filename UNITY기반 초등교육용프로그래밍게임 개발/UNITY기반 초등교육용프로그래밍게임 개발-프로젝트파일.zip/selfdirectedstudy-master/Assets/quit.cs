﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class quit : MonoBehaviour {
	private playerMove player;
	private camera_move camera;
    public Input_Step Step;
    public Input_Step2 Step2;
    public Input_Step3 Step3;
    public Input_Step4 Step4;

    public Input_String Jump;
    public Input_String2 Jump2;
    public Input_String3 Jump3;
    public Input_String4 Jump4;

    public GameObject Input;
    public GameObject Input2;
    public GameObject Input3;
    public GameObject Input4;

    public GameObject str;
    public GameObject str2;
    public GameObject str3;
    public GameObject str4;

    public GameObject GO;
	public Canvas start;
	public Button excute;
	public int x =-6;
	public int y = -2;
	public float delay = 0;
    public int goal = 0;
	void Start(){
		player = GameObject.Find ("player").GetComponent<playerMove> ();
		camera = GameObject.Find ("Main Camera").GetComponent<camera_move> ();

        Step = GameObject.Find("InputField").GetComponent<Input_Step>();
        Step2 = GameObject.Find("InputField2").GetComponent<Input_Step2>();
        Step3 = GameObject.Find("InputField3").GetComponent<Input_Step3>();
        Step4 = GameObject.Find("InputField4").GetComponent<Input_Step4>();
        Jump = GameObject.Find("InputString").GetComponent<Input_String>();
        Jump2 = GameObject.Find("InputString2").GetComponent<Input_String2>();
        Jump3 = GameObject.Find("InputString3").GetComponent<Input_String3>();
        Jump4 = GameObject.Find("InputString4").GetComponent<Input_String4>();

        Input = GameObject.Find("InputField");
        Input.SetActive(false);

        Input2 = GameObject.Find("InputField2");
        Input2.SetActive(false);

        Input3 = GameObject.Find("InputField3");
        Input3.SetActive(false);

        Input4 = GameObject.Find("InputField4");
        Input4.SetActive(false);

        str =  GameObject.Find("InputString");
        str.SetActive(false);
        str2 = GameObject.Find("InputString2");
        str2.SetActive(false);
        str3 = GameObject.Find("InputString3");
        str3.SetActive(false);
        str4 = GameObject.Find("InputString4");
        str4.SetActive(false);
    }

    public void move ()
	{

        //Debug.Log(Step.step);
        if (GameObject.Find ("Slot_right1").transform.FindChild ("Img_I1")) {
           
            
            
            for (int i = 0; i < Step.step; i++)
            {
                x = x + 3;
                iTween.MoveTo(GO, iTween.Hash("x", x, "delay", delay, "time", 1.0f));

                delay += 1.0f;
            }
            
			camera.ResetCamera.x++;
			//delay += 0.5f;
            
			//player.move ();

		} else if (GameObject.Find ("Slot_right1").transform.FindChild ("stringbox1")) {

            if (Jump.Jump == "jump")
            {
				x = x + 3;
				y += 2;
                iTween.MoveTo(GO, iTween.Hash("y", y, "delay", 0f, "time", 0.5f));

                iTween.MoveTo(GO, iTween.Hash("x", x, "delay", 0.5f, "time", 0.5f));
				y -= 2;
				iTween.MoveTo(GO, iTween.Hash("y", y, "delay", 1.0f, "time", 0.5f));

                camera.ResetCamera.x++;
                camera.ResetCamera.x++;
                delay += 1.5f;
              
            }
            else
            {
                Debug.Log("it's not jump");
            }
			//player.jump ();
		}

		if (GameObject.Find ("Slot_right2").transform.FindChild ("Img_I1")) {
            for (int i = 0; i < Step2.step2; i++)
            {
                x = x + 3;
                iTween.MoveTo(GO, iTween.Hash("x", x, "delay", delay, "time", 1.0f));

				delay += 1.0f;
            }
            //player.move ();

        } else if (GameObject.Find ("Slot_right2").transform.FindChild ("stringbox1")) {
            if (Jump2.Jump2 == "jump")
            {
				x = x + 3;
				y += 2;
 
				iTween.MoveTo(GO, iTween.Hash("y", y, "delay", 0f+delay, "time", 0.5f));

				iTween.MoveTo(GO, iTween.Hash("x", x, "delay", 0.5f+delay, "time", 0.5f));
				y -= 2;
				iTween.MoveTo(GO, iTween.Hash("y", y, "delay", 1.0f+delay, "time", 0.5f));
                camera.ResetCamera.x++;
                camera.ResetCamera.x++;
                delay += 1.5f;
               
            }
            else
            {
                Debug.Log("it's not jump");
            }
        }

		if (GameObject.Find ("Slot_right3").transform.FindChild ("Img_I1")) {
            for (int i = 0; i < Step3.step3; i++)
            {
                x = x + 3;
                iTween.MoveTo(GO, iTween.Hash("x", x, "delay", delay, "time", 1.0f));

				delay += 1.0f;
            }

            //player.move ();

        } else if (GameObject.Find ("Slot_right3").transform.FindChild ("stringbox1")) {
            if (Jump3.Jump3 == "jump")
            {
				x = x + 3;
				y += 2;

				iTween.MoveTo(GO, iTween.Hash("y", y, "delay", 0f+delay, "time", 0.5f));

				iTween.MoveTo(GO, iTween.Hash("x", x, "delay", 0.5f+delay, "time", 0.5f));
				y -= 2;
				iTween.MoveTo(GO, iTween.Hash("y", y, "delay", 1.0f+delay, "time", 0.5f));
				camera.ResetCamera.x++;
				camera.ResetCamera.x++;
				delay += 1.5f;
            }
            else
            {
                Debug.Log("it's not jump");
            }
        }

		if (GameObject.Find ("Slot_right4").transform.FindChild ("Img_I1")) {
            for (int i = 0; i < Step4.step4; i++)
            {
                x = x + 3;
                iTween.MoveTo(GO, iTween.Hash("x", x, "delay", delay, "time", 1.0f));

				delay += 1.0f;
            }

            //player.move ();
        } else if (GameObject.Find ("Slot_right4").transform.FindChild ("stringbox1")) {
            if (Jump4.Jump4 == "jump")
            {
				x = x + 3;
				y += 2;

				iTween.MoveTo(GO, iTween.Hash("y", y, "delay", 0f+delay, "time", 0.5f));

				iTween.MoveTo(GO, iTween.Hash("x", x, "delay", 0.5f+delay, "time", 0.5f));
				y -= 2;
				iTween.MoveTo(GO, iTween.Hash("y", y, "delay", 1.0f+delay, "time", 0.5f));
				camera.ResetCamera.x++;
				camera.ResetCamera.x++;
				delay += 1.5f;
            }
            else
            {
                Debug.Log("it's not jump");
            }
        }

		delay = 0;
        if (goal == 0)
        {
            x = -6;
            player.backtoorigin();
        }

    }
}
