﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public class slot_B : MonoBehaviour, IDropHandler
{
	private playerMove player;

	void Start(){
		player = GameObject.Find ("player").GetComponent<playerMove> ();
	}
	public GameObject item
	{
		get
		{
			if (transform.childCount > 0)
			{
				return transform.GetChild(0).gameObject;
			}
			return null;
		}
	}

	#region IDropHandler implementation
	public void OnDrop(PointerEventData eventData)
	{

		if (!item)
		{
			string slotName = transform.gameObject.name;
			string itemDraggedName = DragHandeler.itemBeingDragged.transform.gameObject.name;
			if (slotName.Equals("Slot_B") && (itemDraggedName.Equals("booleanbox")||itemDraggedName.Equals("booleanbox(clone)")))
			{

				DragHandeler.itemBeingDragged.transform.SetParent(transform);
				ExecuteEvents.ExecuteHierarchy<IHasChanged>(gameObject, null, (x, y) => x.HasChanged());
			
			}
		}
	}
	#endregion
}
