﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public class Slot_I : MonoBehaviour, IDropHandler
{

	private playerMove player;

	void Start(){
		player = GameObject.Find ("player").GetComponent<playerMove> ();
	}

	public GameObject item
	{
		get
		{
			if (transform.childCount > 0)
			{
				return transform.GetChild(0).gameObject;
			}
			return null;
		}
	}

	#region IDropHandler implementation
	public void OnDrop(PointerEventData eventData)
	{

		if (!item)
		{
			string slotName = transform.gameObject.name;
			string itemDraggedName = DragHandeler.itemBeingDragged.transform.gameObject.name;
			if (slotName.Equals("Slot_I")  && itemDraggedName.Equals("Img_I"))
			 {
				/*
				GameObject instantiateMe;
				instantiateMe = DragHandeler.itemBeingDragged.transform.gameObject;
				GameObject copy = Instantiate(instantiateMe);
				copy.transform.SetParent(DragHandeler.itemBeingDragged.transform.parent);
*/
			DragHandeler.itemBeingDragged.transform.SetParent(transform);
			ExecuteEvents.ExecuteHierarchy<IHasChanged>(gameObject, null, (x, y) => x.HasChanged());
				//player.count--;
			   }
		}
	}
	#endregion
}
