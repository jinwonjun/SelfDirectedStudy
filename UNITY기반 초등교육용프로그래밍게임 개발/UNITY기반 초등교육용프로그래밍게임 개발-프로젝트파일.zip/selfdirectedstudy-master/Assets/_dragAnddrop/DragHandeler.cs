﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public class DragHandeler : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    public static GameObject itemBeingDragged;
    Vector3 startPosition;
    Transform startParent;
    public GameObject Input;

    #region IBeginDragHandler implementation

    public void OnBeginDrag(PointerEventData eventData)
    {
        itemBeingDragged = gameObject;
        startPosition = transform.position;
        startParent = transform.parent;
      //GetComponent<CanvasGroup>().blocksRaycasts = false;


    }

    #endregion

    #region IDragHandler implementation

    public void OnDrag(PointerEventData eventData)
	{	
        transform.position = eventData.position;
    }

    #endregion

    #region IEndDragHandler implementation

    public void OnEndDrag(PointerEventData eventData)
	{	
        itemBeingDragged = null;
       // GetComponent<CanvasGroup>().blocksRaycasts = true;
        if (transform.parent == startParent)
        {
            transform.position = startPosition;
        }

        //Input = GameObject.Find("InputField");
        //Input.SetActive(true);

    }

    #endregion

	void OnTriggerEnter2D(Collider2D col)
	{
		if (col.gameObject.tag == "delete" &&(!DragHandeler.itemBeingDragged.transform.gameObject.name.Equals("Img_I")&&!DragHandeler.itemBeingDragged.transform.gameObject.name.Equals("stringbox")&&!DragHandeler.itemBeingDragged.transform.gameObject.name.Equals("booleanbox"))) 
		{

            Destroy(this.gameObject);
            GameObject.Find("Canvas").transform.FindChild("InputField2").gameObject.SetActive(false);
            GameObject.Find("Canvas").transform.FindChild("InputField3").gameObject.SetActive(false);
            GameObject.Find("Canvas").transform.FindChild("InputField4").gameObject.SetActive(false);
            GameObject.Find("Canvas").transform.FindChild("InputString").gameObject.SetActive(false);
            GameObject.Find("Canvas").transform.FindChild("InputString2").gameObject.SetActive(false);
            GameObject.Find("Canvas").transform.FindChild("InputString3").gameObject.SetActive(false);
            GameObject.Find("Canvas").transform.FindChild("InputString4").gameObject.SetActive(false);

            if (GameObject.Find("Slot_right1").transform.FindChild("Img_I1"))
            {
                
                GameObject.Find("Canvas").transform.FindChild("InputField").gameObject.SetActive(false);
            }
        }
	}


}
