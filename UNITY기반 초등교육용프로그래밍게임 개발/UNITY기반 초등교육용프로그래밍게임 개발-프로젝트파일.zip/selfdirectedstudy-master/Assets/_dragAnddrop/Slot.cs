﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public class Slot : MonoBehaviour, IDropHandler
{
	private playerMove player;

	void Start(){
		player = GameObject.Find ("player").GetComponent<playerMove> ();
	}
    public GameObject item
    {
        get
        {
            if (transform.childCount > 0)
            {
                return transform.GetChild(0).gameObject;
            }
            return null;
        }
    }

    #region IDropHandler implementation
    public void OnDrop(PointerEventData eventData)
    {
       
        if (!item)
        {
			string slotName = transform.gameObject.name;
			//string slotTag = transform.gameObject.tag;
            string itemDraggedName = DragHandeler.itemBeingDragged.transform.gameObject.name;
			if (slotName.Equals("Slot_right1"))
			{	if(DragHandeler.itemBeingDragged.transform.gameObject.name.Equals("Img_I")||DragHandeler.itemBeingDragged.transform.gameObject.name.Equals("stringbox")||DragHandeler.itemBeingDragged.transform.gameObject.name.Equals("booleanbox"))
				{
                    if (DragHandeler.itemBeingDragged.transform.gameObject.name.Equals("Img_I"))
                    {
                        GameObject.Find("Canvas").transform.FindChild("InputField").gameObject.SetActive(true);
                    }

                    if (DragHandeler.itemBeingDragged.transform.gameObject.name.Equals("stringbox"))
                    {
                        GameObject.Find("Canvas").transform.FindChild("InputString").gameObject.SetActive(true);
                    }



                    GameObject instantiateMe;
					instantiateMe = DragHandeler.itemBeingDragged.transform.gameObject;
					GameObject copy = Instantiate(instantiateMe);
					copy.name = instantiateMe.name+"1";
					copy.transform.SetParent(transform);
					DragHandeler.itemBeingDragged.transform.SetParent(DragHandeler.itemBeingDragged.transform.parent);
				}
			else{
				//copy.transform.SetParent(DragHandeler.itemBeingDragged.transform.parent);
               DragHandeler.itemBeingDragged.transform.SetParent(transform);
			}
                ExecuteEvents.ExecuteHierarchy<IHasChanged>(gameObject, null, (x, y) => x.HasChanged());
			
			}else if(slotName.Equals("Slot_right2"))
			{	if (DragHandeler.itemBeingDragged.transform.gameObject.name.Equals ("Img_I") || DragHandeler.itemBeingDragged.transform.gameObject.name.Equals ("stringbox") || DragHandeler.itemBeingDragged.transform.gameObject.name.Equals ("booleanbox")) {

                    if (DragHandeler.itemBeingDragged.transform.gameObject.name.Equals("Img_I"))
                    {
                        GameObject.Find("Canvas").transform.FindChild("InputField2").gameObject.SetActive(true);
                    }
                    if (DragHandeler.itemBeingDragged.transform.gameObject.name.Equals("stringbox"))
                    {
                        GameObject.Find("Canvas").transform.FindChild("InputString2").gameObject.SetActive(true);
                    }
                    GameObject instantiateMe;
					instantiateMe = DragHandeler.itemBeingDragged.transform.gameObject;
					GameObject copy = Instantiate (instantiateMe);
					copy.name = instantiateMe.name + "1";
					copy.transform.SetParent (transform);
				} else {
					DragHandeler.itemBeingDragged.transform.SetParent (DragHandeler.itemBeingDragged.transform.parent);
				}	
				ExecuteEvents.ExecuteHierarchy<IHasChanged> (gameObject, null, (x, y) => x.HasChanged ());

			}else if(slotName.Equals("Slot_right3"))
			{	if (DragHandeler.itemBeingDragged.transform.gameObject.name.Equals ("Img_I") || DragHandeler.itemBeingDragged.transform.gameObject.name.Equals ("stringbox") || DragHandeler.itemBeingDragged.transform.gameObject.name.Equals ("booleanbox")) {
                    if (DragHandeler.itemBeingDragged.transform.gameObject.name.Equals("Img_I"))
                    {
                        GameObject.Find("Canvas").transform.FindChild("InputField3").gameObject.SetActive(true);
                    }
                    if (DragHandeler.itemBeingDragged.transform.gameObject.name.Equals("stringbox"))
                    {
                        GameObject.Find("Canvas").transform.FindChild("InputString3").gameObject.SetActive(true);
                    }

                    GameObject instantiateMe;
					instantiateMe = DragHandeler.itemBeingDragged.transform.gameObject;
					GameObject copy = Instantiate (instantiateMe);
					copy.name = instantiateMe.name + "1";
					copy.transform.SetParent (transform);
				} else {
					DragHandeler.itemBeingDragged.transform.SetParent (DragHandeler.itemBeingDragged.transform.parent);
				}
			ExecuteEvents.ExecuteHierarchy<IHasChanged>(gameObject, null, (x, y) => x.HasChanged());
			
			}else if(slotName.Equals("Slot_right4"))
			{	if (DragHandeler.itemBeingDragged.transform.gameObject.name.Equals ("Img_I") || DragHandeler.itemBeingDragged.transform.gameObject.name.Equals ("stringbox") || DragHandeler.itemBeingDragged.transform.gameObject.name.Equals ("booleanbox")) {
                    if (DragHandeler.itemBeingDragged.transform.gameObject.name.Equals("Img_I"))
                    {
                        GameObject.Find("Canvas").transform.FindChild("InputField4").gameObject.SetActive(true);
                    }
                    if (DragHandeler.itemBeingDragged.transform.gameObject.name.Equals("stringbox"))
                    {
                        GameObject.Find("Canvas").transform.FindChild("InputString4").gameObject.SetActive(true);
                    }
                    GameObject instantiateMe;
					instantiateMe = DragHandeler.itemBeingDragged.transform.gameObject;
					GameObject copy = Instantiate (instantiateMe);
					copy.name = instantiateMe.name + "1";
					copy.transform.SetParent (transform);
				} else {
					DragHandeler.itemBeingDragged.transform.SetParent (DragHandeler.itemBeingDragged.transform.parent);
				}
				ExecuteEvents.ExecuteHierarchy<IHasChanged>(gameObject, null, (x, y) => x.HasChanged());

			}
        }
    }
    #endregion
}
