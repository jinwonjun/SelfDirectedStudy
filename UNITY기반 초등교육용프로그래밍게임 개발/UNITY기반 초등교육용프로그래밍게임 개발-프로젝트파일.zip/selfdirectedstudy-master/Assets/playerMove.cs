﻿using UnityEngine;
using System.Collections;

public class playerMove : MonoBehaviour {
	public int count = 0;
	public int flag = 0;
	public GameObject mission;
	private Rigidbody2D rb;
	private quit quit;
	private nextLevel nextLevel;
	// Use this for initialization
	Vector3 origin;
	void Start(){
		mission = GameObject.Find ("missionclear");
		mission.SetActive (false);
		rb = GetComponent<Rigidbody2D> ();
		quit = GameObject.Find ("Canvas").GetComponent<quit> ();
		nextLevel = GameObject.Find ("moveTonextLevel").GetComponent<nextLevel> ();
	}

	// Update is called once per frame
	void LateUpdate () {


		//Debug.Log ("player position X:" + transform.position.x + "  Y:" + transform.position.y);
	}

	public void move(){
		Vector3 position = this.transform.position;
		position.x++;
		this.transform.position = position;
	}

	public void jump(){
		Vector3 position = this.transform.position;
		position.x++;
		position.y++;
		position.y++;
		this.transform.position = position;
	}

	public void backtoorigin(){
		origin.x = -6;
		origin.y = -2;
		origin.z = 88;
		/*
		GameObject Img_I1;
		GameObject stringbox;
		GameObject booleanbox;

		Img_I1 = GameObject.Find ("Img_I1");
		stringbox = GameObject.Find ("stringbox1");
		booleanbox = GameObject.Find ("booleanbox1");
	
		Destroy (Img_I1);
		Destroy (stringbox);
		Destroy (booleanbox);*/
		this.transform.position = origin;
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if (col.gameObject.name == "goal") 
		{	
			quit.goal=1;
			nextLevel.moveToNextLevel2();
			//Destroy (this.gameObject);

		}

		if (col.gameObject.name == "goal2") 
		{	
			GameObject.Find("Canvas").transform.FindChild("missionclear").gameObject.SetActive(true);
			//Destroy (this.gameObject);



		}
		if (col.gameObject.name == "Rock") {
			backtoorigin ();
		}
	}
}

