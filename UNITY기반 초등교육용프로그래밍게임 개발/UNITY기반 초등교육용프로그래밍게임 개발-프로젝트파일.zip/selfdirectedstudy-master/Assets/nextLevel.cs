﻿using UnityEngine;
using System.Collections;

public class nextLevel : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}

	public void moveToNextLevel2(){
		Application.LoadLevel ("level2");
	}
}
